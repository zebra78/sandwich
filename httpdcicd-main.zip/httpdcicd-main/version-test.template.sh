#!/bin/bash

if curl -s "http://192.168.100.56:30000/version.html" | grep "tag"
then
    exit 0
else
    exit 1
fi
