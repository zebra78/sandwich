# selfsigned-certs

Copy the files to any location <br>
Ensure permission for .sh file to u+x<br>
Use the command line argument WITH_CA_CERTS preferably for the first time only<br>
Modify the variables defined in the beginning of sh file to reflect those as fieds in the certs<br><br>
$ run sh <br>

<br><br><br>Reference<br>
https://jamielinux.com/docs/openssl-certificate-authority/
